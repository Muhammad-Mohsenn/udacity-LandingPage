/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 * 
*/
let navBar = document.getElementById("navbar__list");

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/



/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav

for (let i = 1; i<=4; i++) {
    let navBarLi = document.createElement("li");
    let navBarLiA = document.createElement("a");
    navBarLiA.setAttribute("href", "#section" +i);
    navBarLiA.setAttribute("class", "btn");
    navBarLiA.setAttribute("class", "active-state");
    let navBarLiText = document.createTextNode("section" + i);

    navBar.appendChild(navBarLi);
    navBarLi.appendChild(navBarLiA);
    navBarLiA.appendChild(navBarLiText);
}



// Add class 'active' to section when near top of viewport

var btns = document.querySelectorAll(".btn");

for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
    var target = document.getElementsByClassName("btn-active");
    target[0].className = target[0].className.replace(" btn-active", "");
    this.className += " btn-active";
  });
}

//Adding active to sections BY CLICKING NOT SCROLLING
var sections = document.querySelectorAll(".sections");

for (var i = 0; i < sections.length; i++) {
  sections[i].addEventListener("click", function() {
    var current = document.getElementsByClassName("active-section");
    current[0].className = current[0].className.replace(" active-section", "");
    this.className += " active-section";
  });
}





const sec = document.querySelectorAll(".sections");
const navLi = document.querySelectorAll(".active-state");

window.addEventListener("scroll", ()=> {
  let current = '';
  sec.forEach(sect => {
    const sectTop = sect.offsetTop;
    const secHeight = sect.clientHeight;
    if (pageYOffset >= (sectTop - secHeight / 3)) {
      current = sect.getAttribute("id");
    }
  })

  navLi.forEach(li => {
    li.classList.remove("active-state");
    if(li.classList.contains(current)) {
      li.classList.add("active-state")
    }
  })
})


// Scroll to anchor ID using scrollTO event


/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 

// Scroll to section on link click

// Set sections as active


